from multiprocessing.sharedctypes import Value
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, \
                                       BaseUserManager

from apiTest.team_choices import TEAM_CHOICES

class UserManager(BaseUserManager):
    def create_user(self, name, team):
        if team not in ["FE", "BE", "PD"]:
            raise ValueError("존재하지 않는 팀입니다.")
        
        user = self.model(
            name=name,
            team=team
        )
        user.save(using=self._db)
        return user

    def create_superuser(self, name, team):
        user = self.create_user(
            name=name,
            team=team
        )
        user.is_staff = True
        user.is_superuser = True
        user.save(using=self._db)
        return user


class User(AbstractBaseUser, PermissionsMixin):
    name = models.CharField(max_length=50, unique=True)
    team = models.CharField(choices=TEAM_CHOICES, max_length=50, default=TEAM_CHOICES[1][0])

    is_staff = models.BooleanField(
        default=False
    )
    objects = UserManager()
    USERNAME_FIELD = 'name'

    def __str__(self):
        return self.name