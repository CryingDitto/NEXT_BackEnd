FRONTEND = 'FE'
BACKEND = 'BE'
PLANNING_DESIGN = "PD"

TEAM_CHOICES = [
    (FRONTEND, "프론트엔드"),
    (BACKEND, "백엔드"),
    (PLANNING_DESIGN, "기획/디자인"),
]