from django.urls import path
from apiTest import views

app_name = 'apiTest'

urlpatterns = [
    path('members/backend', views.BackendMemberListAPIView.as_view()),
    path('members/backend/<int:member_id>', views.BackendMemberAPIView.as_view()),
]