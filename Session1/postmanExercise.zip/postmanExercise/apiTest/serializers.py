from rest_framework import serializers as sz
from django.contrib.auth import get_user_model

class MemberSerializer(sz.ModelSerializer):
    class Meta:
        model = get_user_model()
        fields = ('id', 'name', 'team')