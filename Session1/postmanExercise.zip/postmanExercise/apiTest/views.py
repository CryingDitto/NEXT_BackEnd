from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import User
from .serializers import *

class BackendMemberListAPIView(APIView):
    def get(self, request):
        context = {"msg":"", "data":""}
        backend_members = User.objects.filter(team='BE')

        serializer = MemberSerializer(backend_members, many=True)
        if (len(serializer.data) > 0):
            context["msg"] = "모든 백엔드 팀원 정보를 조회하였습니다."
            context['data'] = serializer.data

            return Response(context, status=status.HTTP_200_OK)
        context["msg"] = "팀원 정보가 존재하지 않습니다."
        context["data"] = None
        return Response(context, status=status.HTTP_200_OK)

    def post(self, request):
        context = {"msg":"", "data":""}
        data = request.data
        data["team"] = "BE"
        serializer = MemberSerializer(data=request.data)
        print(serializer)
        if serializer.is_valid():
            context["msg"] = "성공적으로 정보를 저장하였습니다."
            serializer.save()
            context['data'] = serializer.data
            return Response(context, status=status.HTTP_201_CREATED)
        context["msg"] = "정보 저장에 실패했습니다."
        return Response(context, status=status.HTTP_400_BAD_REQUEST)
        

class BackendMemberAPIView(APIView):
    def put(self, request, member_id):
        context = {"msg":""}
        print(member_id)
        member_name = request.data["name"]
        member = User.objects.get(id=member_id)

        if (member):
            member.name = member_name
            member.save()

            context['msg'] = "이름 수정이 완료되었습니다."
            return Response(context, status=status.HTTP_200_OK)

        context["msg"] = "정보 수정에 실패했습니다."
        return Response(context, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, member_id):
        context = {"msg":"정보 삭제에 실패했습니다."}
        member = User.objects.get(id=member_id)

        if (member):
            member.delete()
            context["msg"] = "정보 삭제가 완료되었습니다."

            return Response(context, status=status.HTTP_200_OK)
        
        return Response(context, status=status.HTTP_404_BAD_REQUEST)

